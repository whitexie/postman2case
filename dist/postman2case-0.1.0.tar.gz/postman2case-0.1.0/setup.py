# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['postman2case']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=5.3,<6.0']

entry_points = \
{'console_scripts': ['postman2case = postman2case.cli:main']}

setup_kwargs = {
    'name': 'postman2case',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
